export type TipoChallenge = {
    rm: number;
    atividade: string;
    nota: number;
}

export type TipoCheckpoint = {
    rm: number;
    atividade: string;
    nota: number;
}

export type TipoGS = {
    rm: number;
    atividade: string;
    nota: number;
}