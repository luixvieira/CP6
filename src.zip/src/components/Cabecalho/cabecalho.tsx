import Menu from "@/components/Menu/Menu"

export default function Cabecalho() {
    return (
        <header className="cabecalho">
            <span>Portifólio</span>
            <Menu/>
        </header>
    )
}