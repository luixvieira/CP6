export default function Rodape() {
    return (
        <footer className='rodape'>
            <h2>✿ ✿ ✿ ✿ ✿ ✿ ✿ ✿ ✿ ✿ <p>. . . . . . . . * * * * * . . . . . . . .</p></h2>
            <p>Grupo de desenvolvedores: <span>Melissa, Luis e Diego</span></p>
        </footer>
    )
}